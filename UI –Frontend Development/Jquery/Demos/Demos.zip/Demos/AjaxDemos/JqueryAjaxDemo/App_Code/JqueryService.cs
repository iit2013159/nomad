using System;
using System.Web;
using System.Collections;
using System.Web.Services;
using System.Web.Services.Protocols;
//refer system.web.extension.dll
using System.Web.Script.Services;
using System.Web.Script.Serialization;
using System.Collections.Generic;

/// <summary>
/// Summary description for JqueryService
/// </summary>
[WebService(Namespace = "http://tempuri.org/")]
[WebServiceBinding(ConformsTo = WsiProfiles.BasicProfile1_1)]

[ScriptService]
public class JqueryService : System.Web.Services.WebService {

    public JqueryService () {

        //Uncomment the following line if using designed components 
        //InitializeComponent(); 
    }

    [WebMethod]
    public string HelloWorld() {
        return "Hello World";
    }

    [WebMethod]
   [ScriptMethod(ResponseFormat = ResponseFormat.Json)]
    public string GetEmployees()
    {
        List<Employee> employeeList = new List<Employee>();
        employeeList.Add(new Employee(101, "Karthik"));
        employeeList.Add(new Employee(102, "Satya"));
        employeeList.Add(new Employee(103, "Mohan"));
        return new JavaScriptSerializer().Serialize(employeeList);

    }


    [WebMethod]
    [ScriptMethod(ResponseFormat = ResponseFormat.Json)]
    public string GetEmployee()
    {
        Employee employee = new Employee(101, "Karthik");
        return new JavaScriptSerializer().Serialize(employee);

    }


    [WebMethod]
    [ScriptMethod(ResponseFormat = ResponseFormat.Xml)]
    public List<Employee> TestXML()
    {
        List<Employee> employeeList = new List<Employee>();
        employeeList.Add(new Employee(101, "Karthik"));
        employeeList.Add(new Employee(102, "Satya"));
        employeeList.Add(new Employee(103, "Mohan"));
        return employeeList;
    }
    
}

