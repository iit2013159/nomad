(function($) {
	$.displayAlert = function(message) {
		alert(message);
	};
})(jQuery);
