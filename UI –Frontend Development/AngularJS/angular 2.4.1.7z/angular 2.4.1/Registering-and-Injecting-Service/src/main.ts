import { Component,Inject,NgModule,OnInit,enableProdMode } from '@angular/core';
import { BrowserModule } from '@angular/platform-browser';
import { platformBrowserDynamic } from '@angular/platform-browser-dynamic';
import { EmployeeService } from './employees/employee.service';
import { IEmployee } from './employees/employee'
enableProdMode();

@Component({
  selector: 'my-app',
  template: `<h1>Employee List</h1>
  <div>
	<ul>
		<li *ngFor="let employee of employees">{{ employee.name }}</li>
	</ul>
  <div>`,
  providers:[ EmployeeService ]
})


export class EmployeeComponent implements OnInit{
  private employees:IEmployee[];
  
  constructor(@Inject(EmployeeService) private empService:EmployeeService){
    
  }
  ngOnInit():void{
    this.employees = this.empService.getAllEmployees();
  }
}

@NgModule({
  imports:[ BrowserModule ],
  declarations:[ EmployeeComponent ],
  bootstrap:[ EmployeeComponent ]
})
class AppModule{}

platformBrowserDynamic().bootstrapModule(AppModule);
  