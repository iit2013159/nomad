export interface Person{
    firstName:string,
    lastName:string
}