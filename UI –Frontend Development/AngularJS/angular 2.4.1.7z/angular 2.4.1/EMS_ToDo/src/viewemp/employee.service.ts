import { Injectable } from '@angular/core';
import { Employee } from './employee';


@Injectable()
export class EmployeeService {
     getEmployee():Employee[]{
        return  [  
             { id: 101, name: 'Ram',desig:'TL' },    
             { id: 102, name: 'Sita',desig:'TL' },    
			 { id: 104, name: 'Ravan',desig:'SSE' },    
			 { id: 109, name: 'Lakshman',desig:'TL' },   
			 { id: 121, name: 'Krish',desig:'TL' },    
			 { id: 141, name: 'Lava',desig:'SE' },    
			 { id: 155, name: 'Kucha',desig:'SE' },  
			 { id: 167, name: 'Shiv',desig:'PM' }			 
           ]
    }
}