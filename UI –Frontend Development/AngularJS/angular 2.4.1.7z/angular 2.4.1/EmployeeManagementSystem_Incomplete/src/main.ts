import { Component, NgModule, enableProdMode } from '@angular/core';
import { BrowserModule } from '@angular/platform-browser';
import { platformBrowserDynamic } from '@angular/platform-browser-dynamic';
import { Routes, RouterModule }   from '@angular/router';
import { HomeComponent } from './home/home.component';
import { ViewEmployeeComponent } from './viewEmp/empView';

enableProdMode();

@Component({
  selector: 'my-app',
   templateUrl:'src/main.html'
})
export class AppComponent { 
}

const routes: Routes = [
  { path: '', redirectTo: '/home', pathMatch: 'full' },
  { path: 'home',  component: HomeComponent },
];

@NgModule({
    imports:[ BrowserModule, RouterModule.forRoot(routes ,{ useHash: true })],
    declarations:[ AppComponent, HomeComponent,ViewEmployeeComponent],
    bootstrap:[ AppComponent ]
})
export class AppModule {
}
platformBrowserDynamic().bootstrapModule(AppModule);