import { Component, NgModule, enableProdMode } from '@angular/core';
import { BrowserModule } from '@angular/platform-browser';
import { platformBrowserDynamic } from '@angular/platform-browser-dynamic';
import 'rxjs/Rx'; 
import { Observable } from 'rxjs/Observable';
enableProdMode();

@Component({
  selector: 'my-app',
  template: '<h1>{{ viewClock | async }}</h1><hr/><button (click)="invokeClock()">Invoke Timer</button>'
})


export class MainComponent {
   private viewClock = Observable.interval(1000);
   private codeClock:Observable<number>;
   invokeClock():void{
       alert('Timer Invoked. Open Console window to see the results');
       this.codeClock = Observable.interval(1000);
       this.codeClock.subscribe(value=>console.log(value));
   }
}


@NgModule({
  imports:[ BrowserModule ],
  declarations:[ MainComponent ],
  bootstrap:[ MainComponent ]
})
class AppModule{}

platformBrowserDynamic().bootstrapModule(AppModule);

  