exports.add = function(firstNumber,secondNumber){
	return firstNumber + secondNumber;
}

exports.multiply = function(firstNumber,secondNumber){
	return firstNumber * secondNumber;
}

/*
module.exports = {
	add : function(firstNumber,secondNumber){
		return firstNumber + secondNumber;
	},
	multiply : function(firstNumber,secondNumber){
		return firstNumber * secondNumber;
	}
}*/