var calc = require('./Calculator');
var addResult = calc.add(6,3);
var multiplyResult = calc.multiply(6,3);
console.log("Addition result = %d",addResult);
console.log("Multiplication result = %d",multiplyResult);

