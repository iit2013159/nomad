var App = require('./components/app');
var React = require('react');
var ReactDOM = require('react-dom');


ReactDOM.render(
    <App/>,document.getElementById('main')
);