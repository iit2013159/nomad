var React = require('react');
var ReactDOM = require('react-DOM');

var App = React.createClass({
    render:function(){
        return (<h1>React with Gulp</h1>)
    }
});
        
module.exports = App;