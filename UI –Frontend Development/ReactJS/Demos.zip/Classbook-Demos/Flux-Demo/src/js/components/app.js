var React = require('react');
var ReactDOM = require('react-dom');
var AppActions = require('../actions/app-actions');
var AppStore = require('../stores/app-stores');

var App = React.createClass({
    handleClick:function(){
        AppActions.addItem('Item to add');
    },
    render:function(){
        return(
            <div>
                <button onClick={this.handleClick}>Click</button>
            </div>
        );
    }
});
module.exports = App;