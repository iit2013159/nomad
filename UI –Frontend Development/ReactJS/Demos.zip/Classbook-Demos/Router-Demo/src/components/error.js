var React = require('react');

var Error = React.createClass({
    render:function(){
        return (
            <h1>Page Not Found</h1>
        );
    }
});

module.exports = Error;


