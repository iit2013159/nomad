var React = require('react');

var Index = React.createClass({
    render:function(){
        return (
            <h1>Home Page</h1>
        );
    }
});

module.exports = Index;


