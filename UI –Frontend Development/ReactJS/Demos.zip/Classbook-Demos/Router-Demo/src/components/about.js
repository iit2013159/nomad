var React = require('react');


var About = React.createClass({
    render:function(){
        return (
            <h1>About Page</h1>
        );
    }
});

module.exports = About;